param($installPath, $toolsPath, $package, $project)
$project.Object.References.Add("System.Data.Entity"); 
$project.Object.References.Add("System.ComponentModel.DataAnnotations"); 
