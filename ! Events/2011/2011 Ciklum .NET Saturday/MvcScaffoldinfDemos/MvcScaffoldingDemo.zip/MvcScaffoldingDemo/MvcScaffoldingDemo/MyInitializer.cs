﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using MvcScaffoldingDemo.Models;

namespace MvcScaffoldingDemo
{
    public class MyInitializer : DropCreateDatabaseIfModelChanges<MvcScaffoldingDemo.Models.MvcScaffoldingDemoContext>
    {
        protected override void Seed(Models.MvcScaffoldingDemoContext context)
        {
            new List<Team>{
                new Team{
                    Name = "team1",
                    Players = new  List<Player>{
                        new Player {
                            Name="player1"
                        },
                        new Player{
                            Name = "player2"
                        }
                    }
                }
            }.ForEach(t => context.Teams.Add(t));

            base.Seed(context);
        }
    }
}
