﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;

namespace PushClient
{
	class Program
	{
		private const string Url = @"http://sn1.notify.live.net/throttledthirdparty/01.00/AAFTkavjFpAuT4i1fIKvueDiAgoOs1ADAgAAAAQOMDAwAAAAAAAAAAAAAAA";

		static void Main(string[] args)
		{
			Console.Write("Header: ");
			string header = Console.ReadLine();
			Console.Write("Text: ");
			string text = Console.ReadLine();
			SendToast(Url, header, text);
			Console.ReadLine();
		}

		static void SendToast(string uri, string header, string text)
		{
			var client = new WebClient();

			client.Headers.Add("Content-Type", "text/html");
			client.Headers.Add("X-NotificationClass", "2");

			var message = "X-WindowsPhone-Target: toast" + Environment.NewLine + Environment.NewLine +
				@"<?xml version=""1.0"" encoding=""utf-8""?>
					<wp:PushNotification xmlns:wp=""WindowsPhonePushNotification"">
						<wp:Toast>
							<wp:Text1>{0}</wp:Text1>
							<wp:Text2>{1}</wp:Text2>
						</wp:Toast>
					</wp:PushNotification>";



			var result = client.UploadString(uri, "POST", String.Format(message, header, text));
			Console.WriteLine(result);
			Console.WriteLine("Device status is {0}", client.ResponseHeaders["X-DeviceConnectionStatus"]);
			Console.WriteLine("Notification status is {0}", client.ResponseHeaders["X-NotificationStatus"]);
		}
	}
}
