﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace Day11_LiveTiles
{
	public partial class MainPage : PhoneApplicationPage
	{
		// Constructor
		public MainPage()
		{
			InitializeComponent();
		}

		private void CountSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			SliderText.Text = Math.Round(CountSlider.Value, 0).ToString();
		}

		private void SadButton_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			SadButton.Opacity = 1;
			SmileButton.Opacity = .5;
		}

		private void SmileButton_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			SmileButton.Opacity = 1;
			SadButton.Opacity = .5;
		}

		private void PrimaryButton_Click(object sender, RoutedEventArgs e)
		{
			ShellTile PrimaryTile = ShellTile.ActiveTiles.First();

			if (PrimaryTile != null)
			{
				StandardTileData tile = new StandardTileData();

				if (SadButton.Opacity == 1)
					tile.BackgroundImage = new Uri("images/sadface.png", UriKind.Relative);
				else if (SmileButton.Opacity == 1)
					tile.BackgroundImage = new Uri("images/smiley.png", UriKind.Relative);
				else { }

				tile.Count = (Int32)Math.Round(CountSlider.Value, 0);
				tile.Title = TitleText.Text;
				PrimaryTile.Update(tile);
			}
		}

		private void SecondaryButton_Click(object sender, RoutedEventArgs e)
		{
			ShellTile SecondaryTile = ShellTile.ActiveTiles.FirstOrDefault(x => x.NavigationUri.ToString().Contains("ID=2"));

			StandardTileData tile = new StandardTileData();
			
			if (SecondaryTile == null)
			{
				tile.BackgroundImage = new Uri("images/yoda.png", UriKind.Relative);
				tile.Title = "Beware...";
				tile.BackTitle = "The Dark Side";
				tile.BackBackgroundImage = new Uri("images/darthvader.png", UriKind.Relative);
				tile.BackContent = "I...am your father.";

				ShellTile.Create(new Uri("/DeepLink.xaml?ID=2", UriKind.Relative), tile);
			}
		}
	}
}