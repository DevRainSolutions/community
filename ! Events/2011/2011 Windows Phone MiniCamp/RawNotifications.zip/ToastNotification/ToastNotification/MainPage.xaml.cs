﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Notification;
using System.Diagnostics;
using System.IO;

namespace ToastNotification
{
    public partial class MainPage : PhoneApplicationPage
    {
        private HttpNotificationChannel notifications;
        private const string notificationServiceName = "Some test";

        public MainPage()
        {
            InitializeComponent();

            SupportedOrientations = SupportedPageOrientation.Portrait | SupportedPageOrientation.Landscape;

            InitializePushChannel();
        }

        private void InitializePushChannel()
        {
            if (notifications != null)
            {
                ShowUri(notifications.ChannelUri);
            }
            else
            {
                try
                {
                    notifications = new HttpNotificationChannel(Application.Current.ToString(), notificationServiceName);
                    notifications.ChannelUriUpdated += new EventHandler<NotificationChannelUriEventArgs>(notifications_ChannelUriUpdated);
                    notifications.HttpNotificationReceived += new EventHandler<HttpNotificationEventArgs>(notifications_HttpNotificationReceived);
                    notifications.Open();
                    ShowUri(notifications.ChannelUri);

                    notifications.BindToShellNotification();
                }
                catch (NotificationChannelExistsException)
                {
                    notifications = HttpNotificationChannel.Find(Application.Current.ToString());
                    notifications.ChannelUriUpdated += new EventHandler<NotificationChannelUriEventArgs>(notifications_ChannelUriUpdated);
                    notifications.HttpNotificationReceived += new EventHandler<HttpNotificationEventArgs>(notifications_HttpNotificationReceived);
                    ShowUri(notifications.ChannelUri);
                }
            }
        }

        void notifications_HttpNotificationReceived(object sender, HttpNotificationEventArgs e)
        {
            using (var r = new StreamReader(e.Notification.Body))
            {
                var data = r.ReadToEnd().Trim('\0');
                Debug.WriteLine(data);

                switch (data)
                {
                    case "red":
                        Dispatcher.BeginInvoke(() => ReceivedData.Foreground = new SolidColorBrush(Colors.Red));
                        break;
                    case "green":
                        Dispatcher.BeginInvoke(() => ReceivedData.Foreground = new SolidColorBrush(Colors.Green));
                        break;
                    case "blue":
                        Dispatcher.BeginInvoke(() => ReceivedData.Foreground = new SolidColorBrush(Colors.Blue));
                        break;
                    case "white":
                        Dispatcher.BeginInvoke(() => ReceivedData.Foreground = new SolidColorBrush(Colors.White));
                        break;
                    case "black":
                        Dispatcher.BeginInvoke(() => ReceivedData.Foreground = new SolidColorBrush(Colors.Black));
                        break;
                    case "yellow":
                        Dispatcher.BeginInvoke(() => ReceivedData.Foreground = new SolidColorBrush(Colors.Yellow));
                        break;
                    case "orange":
                        Dispatcher.BeginInvoke(() => ReceivedData.Foreground = new SolidColorBrush(Colors.Orange));
                        break;
                    case "gray":
                        Dispatcher.BeginInvoke(() => ReceivedData.Foreground = new SolidColorBrush(Colors.Gray));
                        break;
                    default:
                        Dispatcher.BeginInvoke(() => ReceivedData.Text = data);
                        break;
                }
            }
        }

        private void ShowUri(Uri uri)
        {
            if (uri != null)
            {
                Dispatcher.BeginInvoke(() => ChannelUri.Text = uri.ToString());
                Debug.WriteLine(uri.ToString());
            }
        }

        private void notifications_ChannelUriUpdated(object sender, NotificationChannelUriEventArgs e)
        {
            ShowUri(e.ChannelUri);
        }
    }
}