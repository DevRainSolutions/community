﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;

namespace PushClient
{
	class Program
	{
		private const string Url = @"http://sn1.notify.live.net/throttledthirdparty/01.00/AAFTkavjFpAuT4i1fIKvueDiAgoOs1ADAgAAAAQOMDAwAAAAAAAAAAAAAAA";

		static void Main(string[] args)
		{
			while (true)
			{
				Console.Write("Text: ");
				string text = Console.ReadLine();
				SendToast(Url, text);
				Console.ReadLine();
			}
		}

		static void SendToast(string uri, string text)
		{
			var client = new WebClient();

			client.Headers.Add("Content-Type", "text/html");
            client.Headers.Add("X-NotificationClass", "3");

			var result = client.UploadString(uri, "POST", text);
			Console.WriteLine(result);
			Console.WriteLine("Device status is {0}", client.ResponseHeaders["X-DeviceConnectionStatus"]);
			Console.WriteLine("Notification status is {0}", client.ResponseHeaders["X-NotificationStatus"]);
		}
	}
}
