namespace CiklumDemo.Migrations
{
    using System.Data.Entity.Migrations;
    
    public partial class GoalsAdded : DbMigration
    {
        public override void Up()
        {
            AddColumn("Players", "Goals", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("Players", "Goals");
        }
    }
}
