namespace CiklumDemo.Migrations
{
    using System.Data.Entity.Migrations;
    
    public partial class PlayerYearsAdded : DbMigration
    {
        public override void Up()
        {
            DropColumn("Players", "Years");
        }
        
        public override void Down()
        {
            AddColumn("Players", "Years", c => c.Int(nullable: false));
        }
    }
}
