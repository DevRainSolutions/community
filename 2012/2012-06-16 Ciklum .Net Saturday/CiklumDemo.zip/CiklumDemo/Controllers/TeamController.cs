using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CiklumDemo.Models;

namespace CiklumDemo.Controllers
{   
    public class TeamController : Controller
    {
		private readonly ITeamRepository teamRepository;

        public TeamController(ITeamRepository teamRepository)
        {
			this.teamRepository = teamRepository;
        }

        //
        // GET: /Team/

        public ViewResult Index()
        {
            return View(teamRepository.AllIncluding(team => team.Players));
        }

        //
        // GET: /Team/Details/5

        public ViewResult Details(int id)
        {
            return View(teamRepository.Find(id));
        }

        //
        // GET: /Team/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /Team/Create

        [HttpPost]
        public ActionResult Create(Team team)
        {
            if (ModelState.IsValid) {
                teamRepository.InsertOrUpdate(team);
                teamRepository.Save();
                return RedirectToAction("Index");
            } else {
				return View();
			}
        }
        
        //
        // GET: /Team/Edit/5
 
        public ActionResult Edit(int id)
        {
             return View(teamRepository.Find(id));
        }

        //
        // POST: /Team/Edit/5

        [HttpPost]
        public ActionResult Edit(Team team)
        {
            if (ModelState.IsValid) {
                teamRepository.InsertOrUpdate(team);
                teamRepository.Save();
                return RedirectToAction("Index");
            } else {
				return View();
			}
        }

        //
        // GET: /Team/Delete/5
 
        public ActionResult Delete(int id)
        {
            return View(teamRepository.Find(id));
        }

        //
        // POST: /Team/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            teamRepository.Delete(id);
            teamRepository.Save();

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) {
                teamRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

