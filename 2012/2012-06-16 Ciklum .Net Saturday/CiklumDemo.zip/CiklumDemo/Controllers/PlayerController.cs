using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CiklumDemo.Models;

namespace CiklumDemo.Controllers
{   
    public class PlayerController : Controller
    {
		private readonly ITeamRepository teamRepository;
		private readonly IPlayerRepository playerRepository;

		
        public PlayerController(ITeamRepository teamRepository, IPlayerRepository playerRepository)
        {
			this.teamRepository = teamRepository;
			this.playerRepository = playerRepository;
        }

        //
        // GET: /Player/

        public ViewResult Index()
        {
            return View(playerRepository.AllIncluding(player => player.Team));
        }

        //
        // GET: /Player/Details/5

        public ViewResult Details(int id)
        {
            return View(playerRepository.Find(id));
        }

        //
        // GET: /Player/Create

        public ActionResult Create()
        {
			ViewBag.PossibleTeams = teamRepository.All;
            return View();
        } 

        //
        // POST: /Player/Create

        [HttpPost]
        public ActionResult Create(Player player)
        {
            if (ModelState.IsValid) {
                playerRepository.InsertOrUpdate(player);
                playerRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.PossibleTeam = teamRepository.All;
				return View();
			}
        }
        
        //
        // GET: /Player/Edit/5
 
        public ActionResult Edit(int id)
        {
			ViewBag.PossibleTeams = teamRepository.All;
             return View(playerRepository.Find(id));
        }

        //
        // POST: /Player/Edit/5

        [HttpPost]
        public ActionResult Edit(Player player)
        {
            if (ModelState.IsValid) {
                playerRepository.InsertOrUpdate(player);
                playerRepository.Save();
                return RedirectToAction("Index");
            } else {
				ViewBag.PossibleTeam = teamRepository.All;
				return View();
			}
        }

        //
        // GET: /Player/Delete/5
 
        public ActionResult Delete(int id)
        {
            return View(playerRepository.Find(id));
        }

        //
        // POST: /Player/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            playerRepository.Delete(id);
            playerRepository.Save();

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) {
                teamRepository.Dispose();
                playerRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

