﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CiklumDemo.Models
{
    public class Team
    {
        public int Id { get; set; }

        public string Title { get; set; }

        public virtual ICollection<Player> Players { get; set; }
    }
}